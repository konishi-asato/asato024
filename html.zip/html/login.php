<?php
session_start();
require('dbconnect.php');
 
// ★ポイント1★
if (!empty($_POST)) {
    if (($_POST['email'] != '') && ($_POST['password'] != '')) {
        $login = $db->prepare('SELECT * FROM members WHERE email=?');
        $login->execute(array($_POST['email']));
        $member=$login->fetch();
	// 認証
        if ($member != false && password_verify($_POST['password'],$member['password'])) {
            $_SESSION['id'] = $member['id'];
            $_SESSION['time'] =time();
            header('Location: post.php');
            exit();
        } else {
            $error['login']='failed';
        } 
    } else {
        $error['login'] ='blank';
    }
}
?>

	

 
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title> CATHAND </title>
	<style>
		.error { color: red;font-size:0.8em; }
	</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="container">

<header>

<h1 id="logo"><a href="index.html"><img src="images/logo.png" alt="CATHAND"></a></h1>

<!--メニュー-->
<div id="menubar">

<nav>
<ul>
<li><a href="list.php">検索</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="contact.html">CONTACT</a></li>
</ul>
</nav>
</header>
<body>
	<figure class="mb30 c"><img src="images/sample2.jpg" alt=""></figure>
      
     

<form action='' method="post">
    <label style="font-size: 25px;">
        email 　   　
        <input type="text" name="email" style="width:500px; height: 20px;" 
        value="<?php echo htmlspecialchars($_POST['email']??"", ENT_QUOTES); ?>">
    </label>
    <br />

    <label style="font-size: 25px;">
        パスワード
        <input type="password" name="password" style="width:500px; height: 20px;" 
        value="<?php echo htmlspecialchars($_POST['password']??"", ENT_QUOTES); ?>">
    </label>
    <div class="login2">
        <input type="submit" value="ログインする" class="button" style="font-size: 13px; height: 25px;">
    </div>
</form>

    <a href="register.php">ユーザ登録する</a>
</form>

</section>

</main>

<div id="footermenu">
<ul>
<li class="title">メニュー</li>
<li><a href="index.html">ホーム</a></li>

<li><a href="list.php">検索</a></li>
<li><a href="faq.html">よく頂く質問</a></li>
<li><a href="contact.html">お問い合わせ</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
</div>
<!--/#footermenu-->

<footer>


<span class="pr"><a href="" target="_blank"></a></span>

</footer>

</div>
<!--/#container-->

<!--jQueryの読み込み-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--この専用のスクリプト-->
<script src="js/main.js"></script>

<!--開閉ボタン（ハンバーガーアイコン）-->
<div id="menubar_hdr">
<span></span><span></span><span></span>
</div>

<!--ページの上部へ戻るボタン-->
<div class="pagetop"><a href="#"><i class="fas fa-angle-double-up"></i></a></div>

<!--パララックス（inview）-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/protonet-jquery.inview/1.1.2/jquery.inview.min.js"></script>
<script src="js/jquery.inview_set.js"></script>

<!--スライドショー（slick）-->
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="js/slick.js"></script>

</body>
</html>