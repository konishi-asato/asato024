const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

let projects = []; // これは簡単なデモ用の配列です。実際にはデータベースを使用することになります。

io.on('connection', (socket) => {
  console.log('A user connected');

  // 新しい案件を作成
  socket.on('create project', (project) => {
    projects.push(project);
    io.emit('project created', project); // すべてのクライアントに案件をブロードキャスト
  });

  // 接続が切れたときの処理
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

server.listen(3000, () => {
  console.log('Listening on *:3000');
});
