

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>CATHANDサイト</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="取引の内容です">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div id="container">

<header>

<h1 id="logo"><a href="index.html"><img src="images/logo.png" alt="CATHAND"></a></h1>

<!--メニュー-->
<div id="menubar">

<nav>
<ul>
<li><a href="list.php">検索</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="contact.html">CONTACT</a></li>
</ul>
</nav>

<div class="sh">

</div>
<!--/.sh-->

</div>
<!--/#menubar-->

</header>

<main>

<section>

<h2>一覧</h2>

<?php
// list.php

// POSTメソッドで送信されたデータを受け取る
$title = isset($_POST['title']) ? $_POST['title'] : '未指定';
$number = isset($_POST['number']) ? $_POST['number'] : '未指定';
$project_name = isset($_POST['project_name']) ? $_POST['project_name'] : '未指定';
$price = isset($_POST['price']) ? $_POST['price'] : '未指定';
$location = isset($_POST['location']) ? $_POST['location'] : '未指定';
$working_hours = isset($_POST['working_hours']) ? $_POST['working_hours'] : '未指定';

// 既存の静的なマークアップ


echo <<<HTML
<dl class="list2">
	<div>
	<h4><a href="item.php">案件名</a>
	<span class="icon newicon">NEW</span>
	<span class="icon upicon">UP</span>
	<span class="icon">急募</span>
	</h4>
HTML;

// 受け取ったデータを追加
echo "<dt></dt><dd>$title</dd>";
echo "<dt>送信された案件名</dt><dd>$project_name</dd>";
echo "<dt>送信された値段・時給</dt><dd>$price</dd>";
echo "<dt>送信された作業場</dt><dd>$location</dd>";
echo "<dt>送信された作業時間</dt><dd>$working_hours</dd>";
echo "</dl>";
?>


<!--/#footermenu-->

<a href="post.php">新規案件を登録する</a>
<footer>


<span class="pr"><a href="" target="_blank"></a></span>

</footer>

</div>
<!--/#container-->

<!--jQueryの読み込み-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--この専用のスクリプト-->
<script src="js/main.js"></script>

<!--開閉ボタン（ハンバーガーアイコン）-->
<div id="menubar_hdr">
<span></span><span></span><span></span>
</div>

<!--ページの上部へ戻るボタン-->
<div class="pagetop"><a href="#"><i class="fas fa-angle-double-up"></i></a></div>

<!--パララックス（inview）-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/protonet-jquery.inview/1.1.2/jquery.inview.min.js"></script>
<script src="js/jquery.inview_set.js"></script>

<!--スライドショー（slick）-->
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="js/slick.js"></script>

</body>
</html>
