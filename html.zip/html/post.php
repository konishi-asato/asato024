<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>CATHANDサイト</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="取引の内容です">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div id="container">

<header>

<h1 id="logo"><a href="index.html"><img src="images/logo.png" alt="CATHAND"></a></h1>

<!--メニュー-->
<div id="menubar">

<nav>
<ul>
<li><a href="list.php">検索</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="contact.html">CONTACT</a></li>
</ul>
</nav>

<div class="sh">

</div>
<!--/.sh-->

</div>
<!--/#menubar-->

</header>

<main>

<section>

<h2>一覧</h2>
<figure class="mb30 c"><img src="images/sample1.jpg" alt=""></figure>
<?php
session_start();
require('dbconnect.php');




// ★ポイント1★
if (isset($_SESSION['id']) && ($_SESSION['time'] + 3600 > time())) {
    $_SESSION['time'] = time();

    $members=$db->prepare('SELECT * FROM members WHERE id=?');
    $members->execute(array($_SESSION['id']));
    $member=$members->fetch();
} else {
    header('Location: login.php');
    exit();
}
// ★ポイント2★
if (!empty($_POST)) {
    if (isset($_POST['token']) && $_POST['token'] === $_SESSION['token']) {
        $post=$db->prepare('INSERT INTO posts SET created_by=?, post=?, created=NOW()');
        $post->execute(array($member['id'] , $_POST['post']));
        header('Location: post.php');
        exit();
    } else {
        header('Location: login.php');
        exit();
    }
}

// ★ポイント3★
$posts=$db->query('SELECT m.name, p.* FROM members m  JOIN posts p ON m.id=p.created_by ORDER BY p.created DESC');


$TOKEN_LENGTH = 16;
$tokenByte = openssl_random_pseudo_bytes($TOKEN_LENGTH);
$token = bin2hex($tokenByte);
$_SESSION['token'] = $token;

?>

<!DOCTYPE html>
<html lang="ja">

<body>
<!-- ★ログアウト★ -->


<form action="list.php" method="post">
	<input type="hidden" name="token" value="<?=$token?>">
	<?php if (isset($error['login']) &&  ($error['login'] =='token')): ?>
		<p class="error">不正なアクセスです。</p>
	<?php endif; ?>
	<div class="edit">
    <label style="font-size: 25px;">
		<p>
		<?php echo htmlspecialchars($member['name'], ENT_QUOTES); ?>さん、下に案件を記入しましょう
		</p>
		<form action="post.php" method="post">
		<label style="font-size: 25px;">
    <label for="title">タイトル　:</label>
    <input type="text"style="width:500px; height: 20px;"  id="title" name="title"><br>

    <label for="project_name">案件名　　:</label>
    <input type="text" style="width:500px; height: 20px;"  id="project_name" name="project_name"><br>

    <label for="price">値段・時給:</label>
    <input type="text"style="width:500px; height: 20px;"  id="price" name="price" placeholder="時給1,100円〜　作業期間：時給800円"><br>

    <label for="location">作業場　　:</label>
    <input type="text"style="width:500px; height: 20px;"  id="location" name="location" placeholder="兵庫限神戸市"><br>

    <label for="working_hours">作業時間　:</label>
    <input type="text"style="width:500px; height: 20px;"  id="working_hours" name="working_hours" placeholder="19:00〜　1日3時間程度"><br>
	</div>

	 <input type="submit" value="送信" class="button02">
</form>

<?php foreach($posts as $post): ?>
<div class="post">
	<?php echo htmlspecialchars($post['post'], ENT_QUOTES); ?> | 
	<span class="name">
		<?php echo htmlspecialchars($post['name'], ENT_QUOTES); ?> | 
		<?php echo htmlspecialchars($post['created'], ENT_QUOTES); ?> | 

	</span>
</div>
<?php endforeach; ?>
<span class="logout"><a href="login.php">ログアウト</a></span>
</body>
</html>