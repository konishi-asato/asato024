<?php
session_start();
require('dbconnect.php');
// ★ポイント1★
if (!empty($_POST) ){
	// ★ポイント2★
    if ($_POST['name'] == "") {
        $error['name'] = 'blank';
    }
    if ($_POST['email'] == "") {
        $error['email'] = 'blank';
    } else {
		// ★ポイント3★
		$member = $db->prepare('SELECT COUNT(*) AS cnt FROM members WHERE email=?');
		$member->execute(array($_POST['email']));
		$record = $member->fetch();
		if ($record['cnt'] > 0) {
			$error['email'] = 'duplicate';
		}
	}
    if ($_POST['password'] == "") {
        $error['password'] = 'blank';
    }
    if ($_POST['password2'] == "") {
        $error['password2'] = 'blank';
    }
	// ★ポイント4★
    if (strlen($_POST['password'])< 6) {
        $error['password'] = 'length';
    }
	// ★ポイント5★
    if (($_POST['password'] != $_POST['password2']) && ($_POST['password2'] != "")) {
        $error['password2'] = 'difference';
    }
	    if (($_POST['password'] != $_POST['password2']) && ($_POST['password2'] != "")) {
        $error['password2'] = 'difference';
    }

    // 追加：送信後の処理（次回解説します）
    if (empty($error)) {
        $_SESSION['join'] = $_POST;
        header('Location: confirm.php');
        exit();
    }
}
 
//html

?>


<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title> CATHAND </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div id="container">

<header>

<h1 id="logo"><a href="index.html"><img src="images/logo.png" alt="CATHAND"></a></h1>

<!--メニュー-->
<div id="menubar">

<nav>
<ul>
<li><a href="list.php">検索</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="contact.html">CONTACT</a></li>
</ul>
</nav>

<div class="sh">

</div>
<!--/.sh-->

</div>
<!--/#menubar-->

</header>

<body>
	<h2>先生様<span></span></h2>
<figure class="mb30 c"><img src="images/sample1.jpg" alt=""></figure>
	
<form action="" method="post" class="registrationform">
    <label style="font-size: 25px;">
        名前 　    　 　 　 　 
        <input type="text" name="name" style="width:500px; height: 20px;" value="<?php echo $_POST['name']??""; ?>">
    </label>
    <br>
    <label style="font-size: 25px;">
        email　  　 　 　　  
        <input type="text" name="email" style="width:500px; height: 20px;" value="<?php echo $_POST['email']??""; ?>">
    </label>
    <br>
    <label style="font-size: 25px;">
        パスワード　　　
        <input type="password" name="password" style="width:500px; height: 20px;" value="<?php echo $_POST['password']??""; ?>">
    </label>
    <br>
    <label style="font-size: 25px;">
        パスワード再入力
        <input type="password" name="password2" style="width:500px; height: 20px;">
    </label>
    <br>
    <input type="submit" value="確認する" class="button">
</form>

    <a href="login.php">ログイン画面に戻る</a>
</body>
</html>
<div id="footermenu">
<ul>
<li class="title">メニュー</li>
<li><a href="index.html">ホーム</a></li>

<li><a href="list.php">検索</a></li>
<li><a href="faq.html">よく頂く質問</a></li>
<li><a href="contact.html">お問い合わせ</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
<ul>
<li class="title">メニュー各欄</li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
<li><a href="#">例メニュー</a></li>
</ul>
</div>
<!--/#footermenu-->

<footer>


<span class="pr"><a href="" target="_blank"></a></span>

</footer>

</div>
<!--/#container-->

<!--jQueryの読み込み-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--この専用のスクリプト-->
<script src="js/main.js"></script>

<!--開閉ボタン（ハンバーガーアイコン）-->
<div id="menubar_hdr">
<span></span><span></span><span></span>
</div>

<!--ページの上部へ戻るボタン-->
<div class="pagetop"><a href="#"><i class="fas fa-angle-double-up"></i></a></div>

<!--パララックス（inview）-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/protonet-jquery.inview/1.1.2/jquery.inview.min.js"></script>
<script src="js/jquery.inview_set.js"></script>

<!--スライドショー（slick）-->
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="js/slick.js"></script>

</body>
</html>

