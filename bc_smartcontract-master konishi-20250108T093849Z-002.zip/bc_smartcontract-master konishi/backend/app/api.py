import datetime
import hashlib
import json
import os
import shutil
import time
from typing import List

import requests
from fastapi import Depends, FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from starlette.responses import FileResponse
from starlette.staticfiles import StaticFiles

from app import crud, models, schemas
from app import settings
from app.auth.auth_bearer import JWTBearer
from app.auth.auth_handler import encode_jwt
from app.database import SessionLocal, engine
# Variables
from app.email import email_handler

directory_path = settings.STORAGE_PATH
temp_path = settings.TEMP_PATH
secret_key = settings.SECRET_KEY
upload_file = settings.UPLOAD_FILE
update_file = settings.UPDATE_FILE

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Smart Contract FastAPI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Static file
# if not os.path.isdir(directory_path):
#     os.makedirs(directory_path)
# app.mount(f"/{directory_path}", StaticFiles(directory=directory_path), name=directory_path)


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Utility
def check_hash(contract):
    if contract.contract_hash is None:
        contract.contract_hash = ""
    return contract


# USER APIs
@app.post("/users/register")
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    created_user = crud.create_user(db=db, user=user)
    return encode_jwt(created_user.id, user.email, user.name)


@app.post("/users/login")
def login_user(user: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.login_user(user=user, db=db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    else:
        return encode_jwt(db_user.id, db_user.email, db_user.name)


@app.put("/users/{user_id}", dependencies=[Depends(JWTBearer())], response_model=schemas.User)
def update_user(user_id: int, user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return crud.update_user(db, user_id, user)


@app.get("/users", dependencies=[Depends(JWTBearer())], response_model=List[schemas.User])
def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = crud.get_users(db, skip=skip, limit=limit)
    return users


@app.post("/mail", dependencies=[Depends(JWTBearer())], response_model=schemas.User)
def read_user_mail(user: schemas.UserMail, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user is None:
        raise HTTPException(status_code=404, detail="Email not registered yet!")
    return db_user


@app.get("/users/{user_id}", dependencies=[Depends(JWTBearer())], response_model=schemas.User)
def read_user_id(user_id: int, db: Session = Depends(get_db)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user


@app.delete("/users/{user_id}", dependencies=[Depends(JWTBearer())])
def delete_user(user_id: int, db: Session = Depends(get_db)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return crud.delete_user(db, user_id)


# CONTRACT APIs
@app.post("/users/{contractA_id}/contracts/", dependencies=[Depends(JWTBearer())], response_model=schemas.Contract)
def create_contract_for_user(
        contractA_id: int, contract: schemas.ContractCreate,
        db: Session = Depends(get_db)
):
    # contract.contract_file = os.path.join(directory_path, contract.contract_file)
    created_contract = crud.create_user_contract(db=db, contract=contract, contractA_id=contractA_id)
    if created_contract is not None:
        check_hash(created_contract)
        return created_contract
    raise HTTPException(status_code=404, detail="Failed to create contract")


@app.put("/contracts/{contract_id}", dependencies=[Depends(JWTBearer())])
def update_contract_status(
        contract_id: int, contract: schemas.ContractUpdateStatus,
        db: Session = Depends(get_db)
):
    if crud.update_status_contract(db, contract_id, contract) is None:
        raise HTTPException(status_code=404, detail="Contract not found")
    return HTTPException(status_code=200, detail="Contract status updated successfully!")


@app.put("/contracts-hash/{contract_id}", dependencies=[Depends(JWTBearer())])
def update_contract_hash(
        contract_id: int, contract: schemas.ContractUpdateHash,
        db: Session = Depends(get_db)
):
    if crud.update_hash_contract(db, contract_id, contract) is None:
        raise HTTPException(status_code=404, detail="Contract not found")
    return HTTPException(status_code=200, detail="Contract hash updated successfully!")


@app.delete("/contracts/{contract_id}", dependencies=[Depends(JWTBearer())])
def delete_contract(contract_id: int, db: Session = Depends(get_db)):
    is_deleted = crud.delete_contract(db, contract_id)
    if is_deleted:
        return HTTPException(status_code=200, detail="Contract deleted successful")
    raise HTTPException(status_code=404, detail="Contract not found")


@app.get("/contracts", dependencies=[Depends(JWTBearer())], response_model=List[schemas.Contract])
def read_contracts(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    contracts = crud.get_contracts(db, skip=skip, limit=limit)
    results = []
    if len(contracts) != 0:
        for c in contracts:
            check_hash(c)
            results.append(c)
    return results


@app.post("/contracts/search/{hash_value}", response_model=schemas.Contract)
def read_contract_hash(hash_value: str, db: Session = Depends(get_db)):
    # contract.hash_value = secret_key+contract.hash_value
    contract = crud.get_contract_hash(db, hash_value)
    if contract is not None:
        check_hash(contract)
    return contract


@app.post("/contracts/search-mail", response_model=List[schemas.Contract])
def read_contract_mail(email: str, db: Session = Depends(get_db)):
    # contract.hash_value = secret_key+contract.hash_value
    contracts = crud.get_contract_mail(db, email)
    results = []
    if len(contracts) != 0:
        for c in contracts:
            check_hash(c)
            results.append(c)
    return results


@app.get("/contracts/{contract_id}", dependencies=[Depends(JWTBearer())], response_model=schemas.Contract)
def read_contract(contract_id: int, db: Session = Depends(get_db)):
    contract = crud.get_contract(db, contract_id)
    if contract is not None:
        check_hash(contract)
    return contract


@app.get("/users/{contractA_id}/contracts", dependencies=[Depends(JWTBearer())], response_model=List[schemas.Contract])
def read_contract_owner(contractA_id: int, db: Session = Depends(get_db)):
    contracts = crud.get_contracts_owner(db, contractA_id)
    results = []
    if len(contracts) != 0:
        for c in contracts:
            check_hash(c)
            results.append(c)
    return results


@app.get("/clients/{contractB_id}/contracts", dependencies=[Depends(JWTBearer())],
         response_model=List[schemas.Contract])
def read_contracts(contractB_id: int, db: Session = Depends(get_db)):
    contracts = crud.get_contracts_client(db, contractB_id)
    results = []
    if len(contracts) != 0:
        for c in contracts:
            check_hash(c)
            results.append(c)
    return results


# FILE APIs
@app.post("/uploadfiles", dependencies=[Depends(JWTBearer())])
async def create_upload_files(file: UploadFile = File(...)):
    if not os.path.isdir(directory_path):
        os.makedirs(directory_path)
    created_date = datetime.datetime.now().strftime("%d%m%Y")
    created_time = datetime.datetime.now().strftime("%H%M%S")
    sub_path = os.path.join(directory_path, created_date, created_time)
    if not os.path.isdir(sub_path):
        os.makedirs(sub_path)

    with open(os.path.join(sub_path, file.filename), "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    if os.path.isfile(os.path.join(sub_path, file.filename)):
        # return result
        return {"filename": f"{created_date}${created_time}${file.filename}"}
    else:
        # wait for a while
        time.sleep(1)


@app.get("/downloadfiles/{path}", dependencies=[Depends(JWTBearer())])
async def receive_upload_file(path: str):
    paths = path.split("$")
    if len(paths) != 3:
        raise HTTPException(status_code=404, detail="File not found")
    else:
        file_path = directory_path + "/" + path.replace("$", "/")
        if os.path.isfile(file_path):
            # return {"file_link": file_path}
            return FileResponse(path=file_path, media_type='application/pdf', filename=paths[2])
        raise HTTPException(status_code=404, detail="File not found")


@app.post("/hashfiles/{path}", dependencies=[Depends(JWTBearer())])
async def hash_file(path: str):
    paths = path.split("$")
    if len(paths) != 3:
        raise HTTPException(status_code=404, detail="File not found")
    else:
        sub_path = os.path.join(directory_path, paths[0], paths[1], paths[2])
        # print(sub_path)
        if os.path.isfile(sub_path):
            with open(sub_path, "rb") as buffer:
                try:
                    md5_hash = hashlib.md5(buffer.read()).hexdigest()
                    return {"hash_value": md5_hash}
                except Exception as e:
                    raise HTTPException(status_code=404, detail=e)
        else:
            raise HTTPException(status_code=404, detail="File not found")


# EMAIL APIs
@app.post("/mails/{contact_id}", dependencies=[Depends(JWTBearer())])
def send_mails(contact_id: int, email: schemas.MailSend, db: Session = Depends(get_db)):
    if os.path.exists(os.path.join(temp_path, upload_file)) \
            and os.path.exists(os.path.join(temp_path, update_file)):
        db_user = crud.get_user(db, contact_id)
        is_sent = email_handler.send_email(email.type, db_user.email)

        if is_sent:
            return HTTPException(status_code=200, detail="Email sent successfully")
        else:
            raise HTTPException(status_code=404, detail="Send mail failed…")
    raise HTTPException(status_code=404, detail="Send mail failed…")


# BLOCKCHAIN APIs
@app.post("/bc", dependencies=[Depends(JWTBearer())])
def register_bc(info: schemas.RegistInfo, db: Session = Depends(get_db)):
    url = settings.BLOCKCHAIN_ENDPOINT + settings.BLOCKCHAIN_INVOKE

    contractorA = crud.get_user(db, info.contractA_id)
    contractorB = crud.get_user(db, info.contractB_id)

    data = {
        "contractor_a": contractorA.name,
        "contractor_b": contractorB.name,
        "contractor_a_email": contractorA.email,
        "contractor_b_email": contractorB.email,
        "contract_hash": info.contract_hash,
        "date": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"),
        "contract_info": info.contract_info,
    }

    request = requests.post(url, data=data)
    response = json.loads(request.text)

    if "success" in response.keys():
        return HTTPException(status_code=200, detail="BC creating success...")
    else:
        return HTTPException(status_code=404, detail="BC creating failed...")


@app.get("/bc/search-mail/{email}")
def search_bc_mail(email: str):
    url = settings.BLOCKCHAIN_ENDPOINT + settings.BLOCKCHAIN_SEARCH + "?email=" + email

    request = requests.get(url)
    response = request.json()

    if "error" in response.keys():
        return HTTPException(status_code=404, detail="Not found any contracts")
    else:
        return response["results"]


@app.get("/bc/search-hash/{hash_value}")
def search_bc_hash(hash_value: str, db: Session = Depends(get_db)):
    url = settings.BLOCKCHAIN_ENDPOINT + settings.BLOCKCHAIN_SEARCH + "?hash=" + hash_value

    request = requests.get(url)
    response = request.json()

    if "error" in response.keys():
        return HTTPException(status_code=404, detail="Not found any contracts")
    else:
        result = response["results"][0]
        contract = crud.get_contract_hash(db, result.get("contract_hash"))
        if contract is not None:
            result.update({"contract_file": contract.contract_file})
        return result
