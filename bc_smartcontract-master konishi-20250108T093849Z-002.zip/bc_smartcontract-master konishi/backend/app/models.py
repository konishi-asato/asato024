from enum import Enum
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from app.database import Base


class Status(str, Enum):
    under = "under contruction"
    waiting = "waiting for approval"
    approved = "approved"
    rejected = "rejected"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, unique=False, index=True, nullable=False)
    address = Column(String, unique=False, index=True, nullable=False)
    updated = Column(String, unique=False, index=True, nullable=False)
    register_date = Column(String, unique=False, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)


class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    contract_status = Column(String, index=True, nullable=False)
    contract_hash = Column(String, index=True, unique=True, nullable=True)
    contract_info = Column(String, index=True, nullable=False)
    contract_file = Column(String, index=True, nullable=False)
    expired_date = Column(String, index=True, nullable=False)
    updated = Column(String, index=True, nullable=False)
    register_date = Column(String, index=True, nullable=False)

    contractA_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    contractB_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    contractA = relationship("User", backref="contracts", foreign_keys=[contractA_id])
    contractB = relationship("User", foreign_keys=[contractB_id])

