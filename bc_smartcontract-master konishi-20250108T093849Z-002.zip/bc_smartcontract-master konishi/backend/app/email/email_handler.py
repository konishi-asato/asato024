import codecs
import os
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from app import settings

# Variables
sender_email = settings.SENDER_EMAIL
subject = settings.SUBJECT
password = settings.APP_PASSWORD
temp_path = settings.TEMP_PATH
upload_file = settings.UPLOAD_FILE
update_file = settings.UPDATE_FILE


def send_email(setting: int, receiver_email: str):
    # Get email built
    message = message_builder(setting, receiver_email)

    # Create secure connection with server and send email
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("goat-white-0f95da46fac3796a.znlc.jp", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(
                sender_email, receiver_email, message.as_string()
            )
        return True
    except smtplib.SMTPAuthenticationError:
        return False
    except:
        return False


def message_builder(setting: int, receiver_email: str):
    # Message builder
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = sender_email
    message["To"] = receiver_email

    text = settings.TEXT
    html = read_html(setting)

    # Turn these into plain/html MIMEText objects
    part1 = MIMEText(text, "plain")
    part2 = MIMEText(html, "html")

    # Add HTML/plain-text parts to MIMEMultipart message
    # The email client will try to render the last part first
    message.attach(part1)
    message.attach(part2)
    return message


def read_html(setting: int):
    file = codecs.open(os.path.join(temp_path, upload_file), "r", "utf-8")
    if setting == 1:
        file = codecs.open(os.path.join(temp_path, update_file), "r", "utf-8")
    return file.read()
