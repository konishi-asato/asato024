from typing import List, Optional
from pydantic import BaseModel, EmailStr


# CONTRACT SCHEMAS
class ContractBase(BaseModel):
    contract_info: str
    expired_date: str


class Contract(ContractBase):
    id: int
    contract_status: str
    contract_hash: str
    register_date: str
    updated: str
    contract_file: str

    contractA_id: int
    contractB_id: int

    class Config:
        orm_mode = True


class ContractCreate(ContractBase):
    # file: File
    contract_file: str
    contractB_id: int


class ContractUpdateStatus(BaseModel):
    contract_status: str


class ContractUpdateHash(BaseModel):
    contract_hash: str


# class ContractSearch(BaseModel):
#     hash_value: str


# USER SCHEMAS
class UserBase(BaseModel):
    email: EmailStr
    name: str
    address: str


class User(UserBase):
    id: int
    register_date: str
    updated: str
    # contracts: List[Contract] = []

    class Config:
        orm_mode = True


class UserCreate(UserBase):
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserMail(BaseModel):
    email: EmailStr


# EMAIL SCHEMAS
class MailSend(BaseModel):
    type: int


# FILE SCHEMAS
class FilePath(BaseModel):
    file_name = str


# BLOCKCHAIN SCHEMAS
class RegistInfo(BaseModel):
    contract_hash: str
    contract_info: str
    contractA_id: int
    contractB_id: int











