import os
from dotenv import load_dotenv

load_dotenv()

# DB
DATABASE_URL = os.getenv("DATABASE_URL", "postgres://postgres:postgres@localhost:5432/postgres")

# LOCAL STORAGE
STORAGE_PATH = os.getenv("STORAGE_PATH")

# JWT
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM")
JWT_KEY = os.getenv("JWT_KEY")
JWT_CONTRACT = os.getenv("JWT_CONTRACT")
JWT_PWD = os.getenv("JWT_PWD")

# EMAIL CREDENTIAL
SENDER_EMAIL = os.getenv("SENDER_EMAIL", "bc_smartcontract@icraft.jp")
APP_PASSWORD = os.getenv("APP_PASSWORD", "yG9sS*7U")
SUBJECT = os.getenv("SUBJECT","icraft 電子契約管理システム")

# LOCAL STORAGE
TEMP_PATH = os.getenv("TEMP_PATH")
UPLOAD_FILE = "upload.html"
UPDATE_FILE = "update.html"

# EMAIL CONTENT
TEXT = """This is the automatic email sent by the notification system of smart contract application. Please do not reply this 
email address, if there is any problems, please feel free to contact our support department by the following mobile: +(84) 0329455588"""

# SECRET_KEY
SECRET_KEY = os.getenv("SECRET_KEY")

# BLOCKCHAIN
BLOCKCHAIN_ENDPOINT = os.getenv("BLOCKCHAIN_ENDPOINT")
BLOCKCHAIN_INVOKE = os.getenv("BLOCKCHAIN_INVOKE")
BLOCKCHAIN_SEARCH = os.getenv("BLOCKCHAIN_SEARCH")
