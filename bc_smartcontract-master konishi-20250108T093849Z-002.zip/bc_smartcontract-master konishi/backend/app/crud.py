import datetime
import uuid

import jwt

from fastapi import HTTPException
from sqlalchemy.orm import Session
from app import models, schemas, settings

# Variables
jwt_key = settings.JWT_KEY
jwt_algorithm = settings.JWT_ALGORITHM
jwt_contract = settings.JWT_CONTRACT
jwt_pwd = settings.JWT_PWD


# SUPPORT FUNCs
def str_to_byte(value: str):
    return str.encode(value)


# USER FUNCS
def login_user(user: schemas.UserLogin, db: Session):
    db_user = get_user_by_email(db, user.email)
    hashed_input_pwd = jwt.encode({jwt_pwd: user.password},
                                  jwt_key, algorithm=jwt_algorithm)
    if db_user is not None and hashed_input_pwd == db_user.hashed_password:
        return db_user
    else:
        return None


def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()


def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


def get_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.User).offset(skip).limit(limit).all()


def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = jwt.encode({jwt_pwd: user.password},
                                 jwt_key, algorithm=jwt_algorithm)
    date_now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    db_user = models.User(email=user.email, name=user.name, address=user.address, hashed_password=hashed_password,
                          updated=date_now, register_date=date_now)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def update_user(db: Session, user_id: int, user: schemas.UserCreate):
    hashed_password = jwt.encode({jwt_pwd: user.password},
                                 jwt_key, algorithm=jwt_algorithm)
    date_now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    db_user.email = user.email
    db_user.name = user.name
    db_user.address = user.address
    db_user.hashed_password = hashed_password
    db_user.updated = date_now
    db.commit()
    db.refresh(db_user)
    return db_user


def delete_user(db: Session, user_id: int):
    db.query(models.User).filter(models.User.id == user_id).delete()
    db.commit()
    return HTTPException(status_code=200, detail="User deleted successful")


# CONTRACT FUNCS
def create_user_contract(db: Session, contract: schemas.ContractCreate, contractA_id: int):
    # unique_value = f"{uuid.uuid1().hex}${contract.contract_info}${contract.contract_file}"
    # hashed_contract = jwt.encode({jwt_contract: unique_value},
    #                              jwt_key, algorithm=jwt_algorithm)
    date_now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
    try:
        expired_date = datetime.datetime.strptime(contract.expired_date, '%Y-%m-%dT%H:%M').strftime('%d/%m/%Y %H:%M')
    except:
        expired_date = contract.expired_date
    contractor_B = db.query(models.User).filter(models.User.id == contract.contractB_id).first()
    if contractor_B is not None:
        # db_contract = models.Contract(**contract.dict(), contractA_id=contractA_id)
        db_contract = models.Contract(contract_status=models.Status.waiting, contract_info=contract.contract_info,
                                      expired_date=expired_date, updated=date_now, register_date=date_now,
                                      contract_file=contract.contract_file, contractA_id=contractA_id,
                                      contractB_id=contract.contractB_id, contract_hash=None)
        db.add(db_contract)
        db.commit()
        db.refresh(db_contract)
        return db_contract
    return None


def update_status_contract(db: Session, contract_id: int, contract: schemas.ContractUpdateStatus):
    date_now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    db_contract = db.query(models.Contract).filter(models.Contract.id == contract_id).first()
    if db_contract is not None:
        db_contract.updated = date_now
        db_contract.contract_status = contract.contract_status

        db.commit()
        db.refresh(db_contract)
        return True
    else:
        return None


def update_hash_contract(db: Session, contract_id: int, contract: schemas.ContractUpdateHash):
    date_now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    db_contract = db.query(models.Contract).filter(models.Contract.id == contract_id).first()
    if db_contract is not None:
        db_contract.updated = date_now
        db_contract.contract_hash = contract.contract_hash

        db.commit()
        db.refresh(db_contract)
        return True
    else:
        return None


def delete_contract(db: Session, contract_id: int):
    db_contract = get_contract(db, contract_id)
    if db_contract is not None:
        db.query(models.Contract).filter(models.Contract.id == contract_id).delete()
        db.commit()
        return True
    return False


def get_contracts(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Contract).offset(skip).limit(limit).all()


def get_contract(db: Session, contract_id: int):
    return db.query(models.Contract).filter(models.Contract.id == contract_id).first()


def get_contracts_owner(db: Session, user_id: int):
    return db.query(models.Contract).filter(models.Contract.contractA_id == user_id).all()


def get_contracts_client(db: Session, user_id: int):
    return db.query(models.Contract).filter(models.Contract.contractB_id == user_id).all()


def get_contract_hash(db: Session, hash_value: str):
    return db.query(models.Contract).filter(models.Contract.contract_hash == hash_value).first()


def get_contract_mail(db: Session, email: str):
    user = get_user_by_email(db, email)
    if user is not None:
        results = db.query(models.Contract).filter(models.Contract.contractA_id == user.id).all() + \
                  db.query(models.Contract).filter(models.Contract.contractB_id == user.id).all()
        return results
    return []


