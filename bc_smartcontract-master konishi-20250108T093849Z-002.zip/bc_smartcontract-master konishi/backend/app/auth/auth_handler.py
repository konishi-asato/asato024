import time
import jwt

from decouple import config
from typing import Dict
import app.settings as settings

JWT_SECRET = settings.JWT_SECRET
JWT_ALGORITHM = settings.JWT_ALGORITHM


def get_token(token: str):
    return {
        "access_token": token
    }


def encode_jwt(user_id: str, user_email: str, user_name: str) -> Dict[str, str]:
    payload = {
        "user_id": user_id,
        "user_email": user_email,
        "user_name": user_name,
        # "expires": time.time() + 3600
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

    return get_token(token)


def decode_jwt(token: str) -> dict:
    try:
        decoded_token = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        # return decoded_token if decoded_token["expires"] >= time.time() else None
        return decoded_token
    except:
        return {}
