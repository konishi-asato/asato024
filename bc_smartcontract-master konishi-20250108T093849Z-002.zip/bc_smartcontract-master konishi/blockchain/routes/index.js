var express = require('express');
var fabric = require('../fabric');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
});

/**
 * @route GET /api/invoke_contract
 * @param {string} contractor_a.query.required - Name of contractor A
 * @param {string} contractor_b.query.required - Name of contractor B
 * @param {string} contractor_a_email.query.required - Email of contractor A
 * @param {string} contractor_b_email.query.required - Email of contractor B
 * @param {string} contract_hash.query.required - MD5 hash of contract files
 * @param {string} date.query.required - Contract approval date
 * @param {string} contract_info.query.required - Detailing contract
 * @returns {object} 200
 * @returns {Error}  Unexpected error
 */

router.post('/api/invoke_contract', async function(req, res, next) {
    try {
        let body = req.body;
        let fabricContract = await fabric.retrieveContract();
        let contractorA = body.contractor_a;
        let contractorB = body.contractor_b;
        let contractorAEmail = body.contractor_a_email;
        let contractorBEmail = body.contractor_b_email;
        let contractHash = body.contract_hash;
        let date = body.date;
        let contractInfo = body.contract_info;

        await fabricContract.submitTransaction('createContract', contractorA, contractorB, contractorAEmail, contractorBEmail, contractHash, date, contractInfo);
        console.log('Transaction has been submitted');
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.json({ success: true });
    } catch (error) {
        res.json({ error: `${error}` });
    }
});


/**
 * @route POST /api/search_contract
 * @param {string} hash.query - Search contracts by hash value
 * @param {string} email.query - Search contracts by email of contractor
 * @returns {object} 200
 * @returns {Error}  Unexpected error
 */

router.get('/api/search_contract', async function(req, res, next) {
    try {
        let contractList = [];
        let hash = req.query.hash;
        let fabricContract = await fabric.retrieveContract();
        let contractString = await fabricContract.evaluateTransaction('queryContractByHash', hash);
        contractObj = JSON.parse(contractString);
        console.log(`Transaction has been evaluated, result is: ${contractString}`);
        contractList.push(contractObj);

        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.json({
            success: true,
            results: contractList
        });
    } catch (error) {
        res.json({ error: `${error}` });
    }
});

module.exports = router;