# SMART CONTRACT SERVICE

### Cài đặt Environments


Thực thi lệnh sau để cập nhật tất cả các gói software trên system:

```
$ sudo apt-get update
```

Cài đặt curl và golang package

```
$ sudo apt-get install curl
$ sudo apt-get install golang
$ export GOPATH=$HOME/go
$ export PATH=$PATH:$GOPATH/bin
```

Cài đặt Node.js, npm và Python

```
$ sudo apt-get install nodejs
$ sudo apt-get install npm
$ sudo apt-get install python
```

Cài đặt Docker và Docker Compose

```
$ sudo apt-get install docker
$ curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu
$(lsb_release -cs) stable"
$ sudo apt-get update
$ apt-cache policy docker-ce
$ sudo apt-get install -y docker-ce
$ sudo apt-get install docker-compose
$ sudo apt-get upgrade
```

Tùy chỉnh cập nhật Node.js và golang lên các phiên bản thích hợp:

```
$ wget https://dl.google.com/go/go1.11.2.linux-amd64.tar.gz
$ tar -xzvf go1.11.2.linux-amd64.tar.gz
$ sudo mv go/ /usr/local
$ export GOPATH=/usr/local/go
$ export PATH=$PATH:$GOPATH/bin
$ curl -sL https://deb.nodesource.com/setup_8.x | sudo bash -
$ sudo apt-get install -y nodejs
```

Cài đặt Hyperledger Fabric 1.4.7

```
$ cd ~
$ curl -sSL http://bit.ly/2ysbOFE | bash -s -- 1.4.7 1.4.7 0.4.22
```

Lệnh này sẽ tải xuống và thực thi bash script để cài đặt tất cả platform-specific binaries mà chúng ta cần có để thiết lập blockchain network của mình:

<ul>
    <li>configtxgen</li>
    <li>configtxlator</li>
    <li>cryptogen</li>
    <li>discover</li>
    <li>idemixgen</li>
    <li>orderer</li>
    <li>peer</li>
    <li>fabric-ca-client</li>
    <li>fabric-ca-server</li>
</ul>

### Thiết lập Hyperledger Fabric Node SDK và Chaincode

Truy cập đến thư mục root của project:

```
$ cd /path/smart-contract-service
```

Tiếp tục thực thi các lệnh sau:

```
$ sudo cp -r /* $HOME/fabric-samples/fabcar/javascript -f
$ sudo npm --prefix $HOME/fabric-samples/fabcar/javascript install --force
```

### Định nghĩa chaincode

Chaincode được viết bằng nhiều ngôn ngữ, ở đây chúng ta sẽ xem xét chaincode được viết bằng Javascript. Truy cập đến đường dẫn sau:

```
$ cd $HOME/fabric-samples/chaincode/fabcar/javascript/lib
```

Trong tệp fabcar.js chúng ta thêm 2 hàm bên dưới đoạn code "class FabCar extends Contract {":

```
async createContract(ctx, contractor_a, contractor_b, contractor_a_email, contractor_b_email, contract_hash, date, contract_info) {
    console.info('============= START : Create Contract ===========');

    const contract = {
        contractor_a,
        contractor_b,
        contractor_a_email,
        contractor_b_email,
        contract_hash,
        date,
        contract_info,
    };

    await ctx.stub.putState(contract_hash, Buffer.from(JSON.stringify(contract)));
    console.info('============= END : Create Contract ===========');
}

async queryContractByHash(ctx, contractHash) {
    const contractAsBytes = await ctx.stub.getState(contractHash); // get the car from chaincode state
    if (!contractAsBytes || contractAsBytes.length === 0) {
        throw new Error(`${contractHash} does not exist`);
    }
    console.log(contractAsBytes.toString());
    return contractAsBytes.toString();
}
```

Hoặc chúng ta có thể thực thi lệnh sau để sao chép script có sẵn:

```
$ sudo cp /scripts/fabcar.js $HOME/fabric-samples/chaincode/fabcar/javascript/lib -f
```

### Khởi động network

```
$ sudo chmod +x $HOME/fabric-samples/fabcar/startFabric.sh
$ sudo sh $HOME/fabric-samples/fabcar/startFabric.sh javascript
```

### Ghi danh <b>admin</b> user

Khi chúng ta tạo network, một admin user được tạo làm nhà đăng ký cho certificate authority (CA). Bước đầu tiên là tạo private key, public key và chứng chỉ X.509 cho admin user. Quá trình này sử dụng Certificate Signing Request (CSR). Private key, public key được tạo và gửi đến để CA xử lý sau đó trả về chứng chỉ được mã hóa để sử dụng. Ba thông tin đăng nhập này sau đó được lưu trữ trong ví (wallet), cho phép chúng ta hoạt động như một quản trị viên cho CA.

Thực thi lệnh sau để ghi danh admin user:

```
$ sudo node $HOME/fabric-samples/fabcar/javascript/enrollAdmin.js
```

Lệnh này sẽ lưu credentials của administrator trong thư mục wallet.

### Đăng ký và ghi danh <b>user1</b>

Sau khi có credentials của administrator trong thư mục wallet, chúng ta có thể ghi danh user mới là user1. User này được sử dụng để truy vấn và cập nhật ledger:

```
$ sudo node $HOME/fabric-samples/fabcar/javascript/registerUser.js
```

Lệnh này sử dụng CSR để đăng ký user1 và lưu trữ credentials trong thư mục wallet. Giờ đây, chúng ta có identities cho hai user riêng biệt là admin và user1 và những identities này được ứng dụng của chúng ta sử dụng.

Sử dụng lệnh sau để xem cấu trúc thư mục wallet:

```
$ sudo apt-get install tree
$ tree wallet/
```

Kết quả:

```
wallet/
├── admin
│   ├── 319c8417cd39bb523d10cdeeefd04f9cb5b8141b845948bdccb3e69589a1afaf-priv
│   ├── 433365429198fe213c1afa5f30a44c9b15cc7531adf2b474f18dd1defe59d55a-priv
│   ├── 433365429198fe213c1afa5f30a44c9b15cc7531adf2b474f18dd1defe59d55a-pub
│   └── admin
└── user1
    ├── 319c8417cd39bb523d10cdeeefd04f9cb5b8141b845948bdccb3e69589a1afaf-priv
    ├── 319c8417cd39bb523d10cdeeefd04f9cb5b8141b845948bdccb3e69589a1afaf-pub
    └── user1
```

### Khởi động Service

```
$ cd /path/smart-contract-service
$ node bin/www
```

### Một số mẫu ví dụ

##### API ghi thông tin contract vào ledger:

```
curl --location --request POST '/api/invoke_contract' \
--header 'Content-Type: application/json; charset=utf-8' \
--data-raw '{
    "contractor_a": "Aさん",
    "contractor_b": "Bさん",
    "contractor_a_email": "a@gmail.com",
    "contractor_b_email": "b@gmail.com",
    "contract_hash": "3c89991edf51acb06280e90cb2136b84",
    "date": "2021-01-20 130:00:00 JST",
    "contract_info": "Text 3"
}'
```

##### API truy vấn thông tin contract từ ledger:
```
curl --location --request GET '/api/search_contract?hash=3c89991edf51acb06280e90cb2136b84' \
--header 'Content-Type: application/json; charset=utf-8'
```