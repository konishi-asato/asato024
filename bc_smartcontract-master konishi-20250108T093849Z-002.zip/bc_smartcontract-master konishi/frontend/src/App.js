import logo from "./logo.svg";
import "./App.css";
import React, { useState, useEffect } from "react";
import { loginAction } from "./actions/userActions";
import { useDispatch } from "react-redux";
import authStorage from "./auth/authStorage";
import { useSelector } from "react-redux";
import useLink from "./hooks/useLink";
import HomePage from "./pages/HomePage";

function App() {
  const dispatch = useDispatch();
  const [ready, setReady] = useState(false);
  useLink(
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
  );

  const restoreUser = async () => {
    const user = await authStorage.getUser();
    if (!user) return setReady(true);
    dispatch(loginAction(user));
    setReady(true);
  };

  useEffect(() => {
    restoreUser();
  }, []);

  return (
    <>
      {!ready && <></>}
      {ready && <HomePage></HomePage>}
    </>
  );
}

export default App;
