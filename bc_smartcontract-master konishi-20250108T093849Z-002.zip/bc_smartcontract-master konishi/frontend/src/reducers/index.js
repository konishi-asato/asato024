import userReducer from "./userReducer";
import { combineReducers } from "redux";
import contractReducer from "./contractReducer";

const rootReducer = combineReducers({
  user: userReducer,
  contract: contractReducer
});

export default rootReducer;
