import { api } from "./client";

export const login = (email, password) =>
  api.post(`/users/login`, { email, password });

export const register = (email, name, address, password) =>
  api.post("/users/register", { email, name, address, password });

export const getEmail = email => api.post("/mail", { email });
