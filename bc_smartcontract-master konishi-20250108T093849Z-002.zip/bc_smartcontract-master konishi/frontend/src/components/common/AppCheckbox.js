import React from "react";

const FormCheckbox = ({ _text, _onChange, _disabled, _hidden, _checked }) => {
  return (
    <label className="text-muted">
      <input
        type="checkbox"
        onChange={_onChange}
        disabled={_disabled}
        hidden={_hidden}
        checked={_checked}
      ></input>
      {_text}
    </label>
  );
};

export default FormCheckbox;
