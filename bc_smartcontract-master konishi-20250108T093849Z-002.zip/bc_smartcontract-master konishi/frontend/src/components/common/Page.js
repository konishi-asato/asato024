import React from "react";
import Header from "./Header";

const Page = ({ children, _variant, _custom }) => {
  return (
    <div
      className={
        (_variant ? " bg-" + _variant : " bg-light") +
        (_custom ? " " + _custom : "")
      }
    >
      <Header></Header>
      {children}
    </div>
  );
};

export default Page;
