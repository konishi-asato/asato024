import React from "react";

const Container = ({ children, _variant, _shadow }) => {
  return (
    <div
      className={
        "p-3 p-md-5 rounded" +
        (_variant ? " bg-" + _variant : " bg-white") +
        (_shadow ? " shadow-lg" : " shadow-sm")
      }
    >
      {children}
    </div>
  );
};

export default Container;
