import React from "react";

const AppTextInput = ({
  _placeholder,
  _onChange,
  _inputType = "text",
  _iconName,
  _width,
  _roundedPill,
  _name
}) => {
  return (
    <>
      <div
        className={
          "border bg-light p-1" +
          (_width ? " w-" + _width : "") +
          (_roundedPill ? " rounded-pill" : " rounded")
        }
      >
        <div className="input-group">
          <span className="input-group-text bg-light border-0 rounded-pill">
            <i className={"fa fa-" + _iconName}></i>
          </span>
          <input
            type={_inputType}
            className="form-control shadow-none bg-light border-0 rounded-pill"
            placeholder={_placeholder}
            onChange={_onChange}
            name={_name}
          ></input>
        </div>
      </div>
    </>
  );
};

export default AppTextInput;
