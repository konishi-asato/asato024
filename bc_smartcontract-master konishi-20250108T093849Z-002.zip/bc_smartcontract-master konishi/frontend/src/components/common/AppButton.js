import React from "react";
import AppLoader from "./AppLoader";
import "./AppButton.css";

const AppButton = ({
  _text,
  _variant,
  _contentVariant,
  _block,
  _roundedPill,
  _onClick,
  _loading = false,
  _disabled = false,
  _hidden = false,
  _iconName,
  _custom
}) => {
  return (
    <>
      {!_loading && (
        <button
          className={
            "btn py-2 font-weight-bold" +
            (_variant ? " btn-" + _variant : " btn-default") +
            (_contentVariant ? " text-" + _contentVariant : "") +
            (_block ? " btn-block" : "") +
            (_roundedPill ? " rounded-pill" : " rounded") +
            (_custom ? " " + _custom : "")
          }
          onClick={_onClick}
          hidden={_hidden}
          type="button"
          disabled={_disabled}
        >
          {_text + " "}
          <i className={"fa fa-" + _iconName}></i>
        </button>
      )}
      {_loading && (
        <button
          className={
            "btn py-2 font-weight-bold " +
            (_variant ? "btn-" + _variant : "btn-default") +
            (_block ? " btn-block" : "") +
            (_roundedPill ? " rounded-pill" : " rounded") +
            (_custom ? " " + _custom : "")
          }
          disabled={true}
        >
          <AppLoader _height={15}></AppLoader>
        </button>
      )}
    </>
  );
};

export default AppButton;
