import React from "react";

const AppDropdown = ({
  _variant,
  _contentVariant,
  _iconName,
  _block,
  _roundedPill,
  _text,
  _displayToggle,
  _custom,
  _disabled,
  children
}) => {
  return (
    <>
      <button
        type="button"
        className={
          "btn py-2 font-weight-bold" +
          (_variant ? " btn-" + _variant : " btn-default") +
          (_contentVariant ? " text-" + _contentVariant : "") +
          (_block ? " btn-block" : "") +
          (_roundedPill ? " rounded-pill" : " rounded") +
          (_displayToggle ? " dropdown-toggle" : "") +
          (_custom ? " " + _custom : "")
        }
        data-toggle="dropdown"
        disabled={_disabled}
      >
        <i className={"fa fa-" + _iconName}></i> {_text}
      </button>
      <div class="dropdown-menu">{children}</div>
    </>
  );
};

export default AppDropdown;
