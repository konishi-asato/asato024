import React, { useState, useEffect } from "react";
import $ from "jquery";
import LoginModal from "../modal/LoginModal";
import RegisterModal from "../modal/RegisterModal";
import { useSelector } from "react-redux";
import useAuth from "../../auth/useAuth";
import InboxModal from "../modal/InboxModal";
import { StyleSheet, css } from "aphrodite";
import { fadeIn } from "react-animations";
import { motion } from "framer-motion";
import AppDropdown from "./AppDropdown";

const styles = StyleSheet.create({
  red: {
    backgroundColor: "red"
  },

  blue: {
    backgroundColor: "blue"
  },

  hover: {
    ":hover": {
      backgroundColor: "red"
    }
  },

  small: {
    "@media (max-width: 600px)": {
      backgroundColor: "red"
    }
  }
});

const Header = () => {
  const user = useSelector(state => state.user.data);
  const auth = useAuth();

  const logout = () => {
    auth.logout();
    window.location.reload(false);
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        {/* Toggle button */}
        <button
          className="navbar-toggler"
          data-toggle="collapse"
          data-target="#navbarToggler"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Logo */}
        <a className="navbar-brand">LOGO</a>

        <div className="collapse navbar-collapse" id="navbarToggler">
          <div className="ml-auto">
            <ul className="navbar-nav">
              {/* Navbar content start here */}
              {user !== null && (
                <>
                  <div className="my-1"></div>
                  <li className="nav-item dropdown">
                    <AppDropdown
                      _iconName="user"
                      _text={user.user_name}
                      _variant="outline-warning"
                    >
                      <a className="dropdown-item" onClick={() => logout()}>
                        Logout
                      </a>
                      <a
                        className="dropdown-item"
                        onClick={() => $("#loginModal").modal("show")}
                      >
                        Use another account
                      </a>
                    </AppDropdown>
                  </li>

                  <div className="mx-2"></div>
                  <li className="nav-item active">
                    <a
                      className="nav-link"
                      onClick={() => $("#inboxModal").modal("show")}
                    >
                      <i className="fa fa-fw fa-envelope"></i> Inbox
                    </a>
                  </li>
                </>
              )}
              {user === null && (
                <>
                  <div className="mx-1"></div>
                  <li className="nav-item active">
                    <a
                      className="nav-link"
                      onClick={() => $("#loginModal").modal("show")}
                    >
                      <i className="fa fa-fw fa-user"></i> Login
                    </a>
                  </li>
                </>
              )}

              <div className="mx-1"></div>
              <li className="nav-item active">
                <a className="nav-link">
                  <i className="fa fa-fw fa-cog"></i> Setting
                </a>
              </li>
              {/* Navbar content end here */}
            </ul>
          </div>
        </div>
      </nav>
      <LoginModal _id="loginModal"></LoginModal>
      <RegisterModal _id="registerModal"></RegisterModal>
      <InboxModal _id="inboxModal"></InboxModal>
    </>
  );
};

export default Header;
