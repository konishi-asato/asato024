import React from "react";
import AppButton from "../common/AppButton";

const KeyModal = ({ _id, _key }) => {
  return (
    <div
      id={_id}
      className="modal fade overflow-auto"
      tabindex="-1"
      role="dialog"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="text-center">Contract Key</h5>
            <button type="button" className="close" data-dismiss="modal">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div className="modal-body modal-single">
            {_key !== "" && (
              <div className="row">
                <div className="col-9">
                  <p>{_key}</p>
                </div>
                <div className="col-3">
                  <AppButton
                    _iconName="clipboard"
                    _text="Copy"
                    _variant="outline-info"
                    _onClick={() => {
                      navigator.clipboard.writeText(_key);
                    }}
                  ></AppButton>
                </div>
              </div>
            )}
            {_key === "" && <p>This contract is not yet registered.</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default KeyModal;
