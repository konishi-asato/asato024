import React, { useEffect } from "react";
import DataTable from "../table/DataTable";
import { getContractsByClientId } from "../../api/contractApi";
import useApi from "../../hooks/useApi";
import { useSelector } from "react-redux";
import ContractInboxTableItem from "../table/ContractInboxTableItem";
import AppLoader from "../common/AppLoader";
import AppButton from "../common/AppButton";
import KeyModalList from "./KeyModalList";
import Table from "../table/Table";

const InboxModal = ({ _id }) => {
  const user = useSelector(state => state.user.data);
  const getContractsByClientIdApi = useApi(getContractsByClientId);

  useEffect(() => {
    if (user != null) {
      getContractsByClientIdApi.request(user.user_id);
    }
  }, []);

  return (
    <div
      id={_id}
      className="modal fade overflow-auto"
      tabindex="-1"
      role="dialog"
    >
      <div className="modal-dialog mw-100 w-75">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div className="modal-body modal-single">
            <h5 className="text-center">Inbox</h5>
            {getContractsByClientIdApi.loading && <AppLoader></AppLoader>}
            {getContractsByClientIdApi.success && (
              <Table
                _component={ContractInboxTableItem}
                _data={getContractsByClientIdApi.data}
                _headers={["Info", "Status", "Updated Date", ""]}
              ></Table>
            )}
            <KeyModalList
              _id="keyInboxModal"
              _data={getContractsByClientIdApi.data}
            ></KeyModalList>{" "}
            {getContractsByClientIdApi.error && (
              <>
                <p className="text-muted text-center">
                  There is a connection error!
                </p>
                <div className="d-flex justify-content-center">
                  <AppButton
                    _variant="outline-info"
                    _text={"Retry"}
                    _iconName="refresh"
                    _onClick={() =>
                      getContractsByClientIdApi.request(user.user_id)
                    }
                  ></AppButton>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InboxModal;
