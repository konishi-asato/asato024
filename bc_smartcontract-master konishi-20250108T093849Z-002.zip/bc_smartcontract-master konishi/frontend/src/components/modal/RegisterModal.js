import React, { useState } from "react";
import AppTextInput from "../common/AppTextInput";
import AppButton from "../common/AppButton";

import $ from "jquery";
import { login, register } from "../../api/authApi";

import useApi from "../../hooks/useApi";
import useAuth from "../../auth/useAuth";
const LoginModal = ({ _id }) => {
  const auth = useAuth();
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [address, setAddress] = useState();
  const [password, setPassword] = useState();
  const [policyAgree, setPoilicyAgree] = useState(false);

  const registerApi = useApi(register);
  const loginApi = useApi(login);

  const registerHanling = async () => {
    const response = await registerApi.request(email, name, address, password);
    if (response.ok) {
      alert("Register Success");
      loginHandling();
    } else {
      alert("Register Failed");
    }
  };

  const loginHandling = async () => {
    const response = await loginApi.request(email, password);
    if (response.ok) {
      if (response.data.length !== 0) {
        alert("Login Success");
        auth.login(response.data.access_token);
        // $("#registerModal").modal("hide");
        window.location.reload(false);
      } else {
        alert("Invalid name or password");
      }
    } else {
      alert("Login Failed");
    }
  };

  return (
    <div
      id={_id}
      className="modal fade overflow-auto"
      tabindex="-1"
      role="dialog"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div className="modal-body modal-single">
            <h5 className="text-center">Register</h5>
            <AppTextInput
              _iconName="envelope"
              _placeholder="Email"
              _roundedPill
              _onChange={event => setEmail(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _iconName="user"
              _placeholder="Name"
              _roundedPill
              _onChange={event => setName(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _iconName="map-marker"
              _placeholder="Address"
              _roundedPill
              _onChange={event => setAddress(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _iconName="lock"
              _placeholder="Password"
              _roundedPill
              _inputType="password"
              _onChange={event => setPassword(event.target.value)}
            ></AppTextInput>
            <br></br>
            {/* <AppCheckbox _text="Please agree to the Terms of Use & Privacy Policy"></AppCheckbox> */}
            <AppButton
              _text="Register"
              _variant="outline-info"
              _block
              _onClick={() => registerHanling()}
              _loading={registerApi.loading || loginApi.loading}
            ></AppButton>
            <br></br>
            <p className="text-muted text-center">Already have an account?</p>
            <AppButton
              _text="Login"
              _variant="outline-info"
              _block
              _onClick={() => {
                $("#registerModal").modal("hide");
                $("#loginModal").modal("show");
              }}
            ></AppButton>
            <br></br>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginModal;
