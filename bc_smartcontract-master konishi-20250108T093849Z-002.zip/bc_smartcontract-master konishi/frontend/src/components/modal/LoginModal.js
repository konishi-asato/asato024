import React, { useState } from "react";
import AppTextInput from "../common/AppTextInput";
import AppButton from "../common/AppButton";
import $ from "jquery";
import { login } from "../../api/authApi";
import useApi from "../../hooks/useApi";
import useAuth from "../../auth/useAuth";

const LoginModal = ({ _id }) => {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const loginApi = useApi(login);
  const auth = useAuth();

  const loginHandling = async () => {
    const response = await loginApi.request(email, password);
    if (response.ok) {
      if (response.data.length !== 0) {
        alert("Login Success");
        auth.login(response.data.access_token);
        window.location.reload(false);
      } else {
        alert("Invalid name or password");
      }
    } else {
      alert("Login Failed");
    }
  };

  return (
    <div
      id={_id}
      className="modal fade overflow-auto"
      tabindex="-1"
      role="dialog"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div className="modal-body modal-single">
            <h5 className="text-center">Login</h5>
            <AppTextInput
              _iconName="envelope"
              _placeholder="Email"
              _roundedPill
              _onChange={event => setEmail(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _iconName="lock"
              _placeholder="Password"
              _roundedPill
              _inputType="password"
              _onChange={event => setPassword(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppButton
              _text="Login"
              _variant="outline-info"
              _block
              _loading={loginApi.loading}
              _onClick={() => loginHandling()}
            ></AppButton>
            <br></br>
            <p className="text-muted text-center">Don't have an account?</p>
            <AppButton
              _text="Register"
              _variant="outline-info"
              _block={true}
              _onClick={() => {
                $("#loginModal").modal("hide");
                $("#registerModal").modal("show");
              }}
            ></AppButton>
            <br></br>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginModal;
