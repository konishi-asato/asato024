import React from "react";
import KeyModal from "./KeyModal";

const KeyModalList = ({ _id, _data }) => {
  return (
    <>
      {_data.map((item, i) => {
        return (
          <KeyModal _id={_id + item.id} _key={item.contract_hash}></KeyModal>
        );
      })}
    </>
  );
};

export default KeyModalList;
