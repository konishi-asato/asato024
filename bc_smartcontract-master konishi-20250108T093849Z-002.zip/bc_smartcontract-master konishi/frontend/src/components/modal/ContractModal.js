import React, { useState, useEffect } from "react";
import AppTextInput from "../common/AppTextInput";
import $ from "jquery";
import { getEmail } from "../../api/authApi";
import useApi from "../../hooks/useApi";
import AppDropzone from "../common/AppDropzone";
import Dropzone from "react-dropzone-uploader";
import {
  createContract,
  uploadFile,
  sendContractEmail
} from "../../api/contractApi";
import { useSelector } from "react-redux";
import authStorage from "../../auth/authStorage";
import baseURL from "../../api/baseURL";
import xhr from "xhr";
import { useDispatch } from "react-redux";
import { addContract } from "../../actions/contractActions";

const ContractModal = ({ _id }) => {
  const user = useSelector(state => state.user.data);
  const dispatch = useDispatch();
  const [clientEmail, setClientEmail] = useState();
  const [contractInfo, setContractInfo] = useState();
  const [expiredDate, setExpiredDate] = useState();
  const [filename, setFilename] = useState();

  const createContractApi = useApi(createContract);
  const uploadFileApi = useApi(uploadFile);
  const sendContractEmailApi = useApi(sendContractEmail);
  const getEmailApi = useApi(getEmail);

  const getEmailHandling = async email => {
    if (email == user.user_email) {
      alert("Cannot send contract to yourself");
      return;
    }
    const response = await getEmailApi.request(email);
    if (response.ok) {
      createContractHandling(
        user.user_id,
        contractInfo,
        expiredDate,
        // files[0].meta.name,
        filename,
        response.data.id
      );
    } else {
      alert("Email does not exist");
    }
  };

  const createContractHandling = async (
    userId,
    contractInfo,
    expiredDate,
    contractFile,
    clientEmail
  ) => {
    const response = await createContractApi.request(
      userId,
      contractInfo,
      expiredDate,
      contractFile,
      clientEmail
    );

    if (response.ok) {
      alert("Create Contract Success");
      console.log(response.data);
      dispatch(addContract(response.data));
      sendContractEmailHandling(clientEmail);
    } else {
      alert("Create Contract Failed");
    }
  };

  const sendContractEmailHandling = async clientEmail => {
    const response = await sendContractEmailApi.request(0, clientEmail);
    if (response.ok) {
      alert("Mail sent");
      $("#contractModal").modal("hide");
    } else {
      alert("Send mail fail");
    }
  };

  // specify upload params and url for your files
  const getUploadParams = async ({ file }) => {
    const authToken = await authStorage.getToken();
    const body = new FormData();
    body.append("file", file);
    return {
      url: baseURL + "/uploadfiles",
      body,
      headers: { Authorization: "Bearer " + authToken }
    };
  };

  // called every time a file's `status` changes
  const handleChangeStatus = ({ meta, file, xhr }, status) => {
    console.log(status, meta, file);
    if (status == "done") {
      var json = JSON.parse(xhr.response);
      setFilename(json.filename);
    }
  };

  // receives array of files that are done uploading when submit button is clicked
  const handleSubmit = async (files, allFiles) => {
    // const body = new FormData();
    // body.append("file", files[0].meta);
    // contractApi.uploadFile(body);
    getEmailHandling(clientEmail);
  };

  return (
    <div
      id={_id}
      className="modal fade overflow-auto"
      tabindex="-1"
      role="dialog"
    >
      <div className="modal-dialog mw-100 w-75">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div className="modal-body modal-single">
            <h5 className="text-center">Create Contract</h5>
            <AppTextInput
              _iconName="envelope"
              _placeholder="To Contractor"
              _roundedPill
              _onChange={event => setClientEmail(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _width={50}
              _placeholder="To Contractor"
              _inputType="datetime-local"
              _roundedPill
              _onChange={event => setExpiredDate(event.target.value)}
            ></AppTextInput>
            <br></br>
            <AppTextInput
              _placeholder="Contract Information"
              _roundedPill
              _onChange={event => setContractInfo(event.target.value)}
            ></AppTextInput>
            <br></br>
            <Dropzone
              getUploadParams={getUploadParams}
              onChangeStatus={handleChangeStatus}
              onSubmit={handleSubmit}
              maxFiles={1}
              multiple={false}
              disabled={
                getEmailApi.loading ||
                createContractApi.loading ||
                sendContractEmailApi.loading
              }
              accept=".pdf"
            ></Dropzone>
            <br></br>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContractModal;
