const dummyData = [
  {
    contract_status: "under construction",
    contract_file: "Java at Viet nam",
    contractA_id: 1,
    contract_info: "Aprotrain Aptech",
    location: "Vietnam",
    updated: "AAA",
    contract_hash:
      "https://media-exp1.licdn.com/dms/image/C5603AQE1G9E1Sn2eJA/profile-displayphoto-shrink_400_400/0/1598955597953?e=1614816000&v=beta&t=pDroFgNBSdeiWzfCpB8d8bepUMEV3a2_EHYbokpinSc"
  }
];

export default dummyData;
