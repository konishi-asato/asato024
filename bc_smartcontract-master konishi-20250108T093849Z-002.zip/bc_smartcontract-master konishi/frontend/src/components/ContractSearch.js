import React, { useState } from "react";
import AppButton from "../components/common/AppButton";
import AppTextInput from "../components/common/AppTextInput";
import {
  searchContract,
  updateContractHash,
  hashFile,
  registerBlockchain,
  searchBlockchain
} from "../api/contractApi";
import useApi from "../hooks/useApi";
import ContractSearchTableItem from "./table/ContractSearchTableItem";
import DataTable from "./table/DataTable";
import { useSelector, useDispatch } from "react-redux";
import { registerContract } from "../actions/contractActions";

const ContractSearch = () => {
  const dispatch = useDispatch();
  const [hashValue, setHashValue] = useState("");
  const contracts = useSelector(state => state.contract.selectedList);

  // api
  const hashFileApi = useApi(hashFile);
  const updateContractHashApi = useApi(updateContractHash);
  const searchContractApi = useApi(searchContract);
  const registerBlockChainApi = useApi(registerBlockchain);
  const searchBlockchainApi = useApi(searchBlockchain);

  const uploadBlockchainHandling = () => {
    const promises = [];

    for (let i = 0; i < contracts.length; i++) {
      promises.push(hashFileHandling(contracts[i]));
    }

    Promise.all(promises).then(() => {
      // dispatch(registerContracts(contrac));
      // window.location.reload(false);
    });
  };

  const hashFileHandling = async contract => {
    const response = await hashFileApi.request(contract.contract_file);
    if (response.ok) {
      await updateContractHashHandling(contract, response.data.hash_value);
      console.log("hashFile succ");
    } else {
      console.log("hashFile failed");
    }
  };

  const updateContractHashHandling = async (contract, hash) => {
    const response = await updateContractHashApi.request(contract.id, hash);
    if (response.ok) {
      dispatch(registerContract(contract.id, hash));
      await registerBlockChainHandling(
        contract.contractA_id,
        contract.contractB_id,
        contract.contract_info,
        hash
      );
    } else {
      alert("update hashFile failed");
    }
  };

  const registerBlockChainHandling = async (
    userId,
    clientId,
    contractInfo,
    contractHash
  ) => {
    const response = await registerBlockChainApi.request(
      userId,
      clientId,
      contractInfo,
      contractHash
    );
  };

  const seachContractHandling = async () => {
    const response = await searchContractApi.request(hashValue);
    if (response.ok) {
      console.log(response.data);
    }
  };

  const searchBlockchainHandling = async () => {
    const response = await searchBlockchainApi.request(hashValue);
    if (response.ok) {
      console.log(response.data);
    }
  };

  return (
    <div>
      <strong>Search Blockchain</strong>
      <br></br>
      <br></br>
      <AppTextInput
        _iconName="search"
        _placeholder="Search Blockchain"
        _roundedPill
        _onChange={event => setHashValue(event.target.value)}
      ></AppTextInput>
      <br></br>
      <div className="btn-group">
        <AppButton
          _variant="outline-info"
          _text=""
          _iconName="plus-square"
          _onClick={() => uploadBlockchainHandling()}
          _loading={hashFileApi.loading || updateContractHashApi.loading}
        ></AppButton>
        <div className="mx-2"></div>
        {/* <AppButton
          _variant="outline-info"
          _text="Search"
          _iconName="search"
          _onClick={() => seachContractHandling()}
          _loading={searchContractApi.loading}
        ></AppButton> */}
        <AppButton
          _variant="outline-info"
          _text="Search"
          _iconName="search"
          _onClick={() => searchBlockchainHandling()}
          _loading={searchBlockchainApi.loading}
        ></AppButton>
      </div>
      <br></br>
      <br></br>
      {searchContractApi.success && searchContractApi.data !== null && (
        <DataTable
          _headers={["Info", "Contractor-A", "Contractor-B", ""]}
          _component={ContractSearchTableItem}
          _data={[searchContractApi.data]}
        ></DataTable>
      )}
      {searchBlockchainApi.success && searchBlockchainApi.data !== null && (
        <DataTable
          _headers={["Info", "Contractor-A", "Contractor-B", ""]}
          _component={ContractSearchTableItem}
          _data={[searchBlockchainApi.data]}
        ></DataTable>
      )}
      {searchContractApi.success && searchContractApi.data === null && (
        <p className="text-muted text-center">There is no matching result</p>
      )}
    </div>
  );
};

export default ContractSearch;
