import React from "react";

const Pagination = ({ _previousOnClick, _nextOnClick, _pageNumbers }) => {
  return (
    <nav>
      <ul className="pagination justify-content-center">
        <li className="page-item">
          <a className="page-link" onClick={_previousOnClick} tabIndex="-1">
            Previous
          </a>
        </li>
        {_pageNumbers.map((item, i) => {
          return item;
        })}
        <li className="page-item">
          <a className="page-link" onClick={_nextOnClick}>
            Next
          </a>
        </li>
      </ul>
    </nav>
  );
};

export default Pagination;
