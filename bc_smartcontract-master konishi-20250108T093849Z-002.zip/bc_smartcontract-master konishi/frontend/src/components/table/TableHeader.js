import React from "react";

const TableHeader = ({ _headers }) => {
  return (
    <tr className="bg-dark text-white">
      {_headers.map((header, i) => {
        return (
          <>
            {i === 0 && <th className="rounded-left">{header}</th>}
            {i !== 0 && i !== _headers.length - 1 && <th>{header}</th>}
            {i === _headers.length - 1 && (
              <th className="rounded-right">{header}</th>
            )}
          </>
        );
      })}
    </tr>
  );
};

export default TableHeader;
