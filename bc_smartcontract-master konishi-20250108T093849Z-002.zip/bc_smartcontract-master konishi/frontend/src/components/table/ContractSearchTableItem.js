import React from "react";
import { downloadFile } from "../../api/contractApi";
import useApi from "../../hooks/useApi";
import { downloadPdf } from "../../helpers/downloader";

const ContractSearchTableItem = ({ _item, _key }) => {
  const downloadFileApi = useApi(downloadFile);

  const downloadFileHandling = async contractFile => {
    const response = await downloadFileApi.request(contractFile);
    if (response.ok) {
      downloadPdf(_item.contract_file.split("$")[2], response.data);
    } else {
      console.log("WHERE IS THE FILE???");
    }
  };

  return (
    <tr key={_key}>
      <td className="align-middle">
        <p className="text-muted">{_item.contract_info}</p>
      </td>
      <td className="align-middle">
        <p className="text-muted">{_item.contractor_a}</p>
      </td>
      <td className="align-middle">
        <p className="text-muted">{_item.contractor_b}</p>
      </td>
      <td className="align-middle">
        <button type="button" className="btn" data-toggle="dropdown">
          <i className="fa fa-ellipsis-v text-muted"></i>
        </button>
        <div class="dropdown-menu">
          <a
            class="dropdown-item"
            onClick={() => downloadFileHandling(_item.contract_file)}
          >
            Download
          </a>
        </div>
      </td>
    </tr>
  );
};

export default ContractSearchTableItem;
