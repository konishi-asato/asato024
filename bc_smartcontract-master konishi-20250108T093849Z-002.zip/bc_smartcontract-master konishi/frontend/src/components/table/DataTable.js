import React, { useEffect } from "react";
import TableHeader from "./TableHeader";
import Pagination from "./Pagination";
import usePagination from "./usePagination";

// uncomment these for datatable.met
// import $ from "jquery";
// import useLink from "../../hooks/useLink";
// import "datatables.net-dt/js/dataTables.dataTables";

const DataTable = ({ _data, _headers = [], _component, _id }) => {
  const pagination = usePagination(_data);

  // uncomment useLink and useEffect for datatable.net
  // useLink("https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css");

  // useEffect(() => {
  //   $("#" + _id).DataTable({
  //     bInfo: false
  //   });
  // }, []);

  return (
    <>
      {_data.length !== 0 && (
        <>
          <div className="table-responsive">
            <table id={_id} className="table">
              <thead>
                <TableHeader _headers={_headers}></TableHeader>
              </thead>

              <tbody>
                {pagination.currentItems.map((item, i) => {
                  return <_component _item={item} _key={i}></_component>;
                })}
              </tbody>
              {/* <tbody>
                {_data.map((item, i) => {
                  return <_component _item={item} _key={i}></_component>;
                })}
              </tbody> */}
            </table>
          </div>
          <Pagination
            _previousOnClick={() => {
              if (pagination.currentPage !== 1)
                pagination.setCurrentPage(pagination.currentPage - 1);
            }}
            _nextOnClick={() =>
              pagination.setCurrentPage(pagination.currentPage + 1)
            }
            _pageNumbers={pagination.pageNumbers}
          ></Pagination>
        </>
      )}
      {_data.length === 0 && (
        <>
          <div className="table-responsive">
            <table id={_id} className="table">
              <thead>
                <TableHeader _headers={_headers}></TableHeader>
              </thead>
            </table>
          </div>
          <p className="text-secondary text-center">
            There is no contract to display
          </p>
        </>
      )}
    </>
  );
};

export default DataTable;
