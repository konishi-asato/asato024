import React, { useState, useEffect } from "react";
import AppDropdown from "../common/AppDropdown";
import {
  updateContract,
  downloadFile,
  sendContractEmail
} from "../../api/contractApi";
import useApi from "../../hooks/useApi";
import AppButton from "../common/AppButton";
import { useSelector } from "react-redux";
import $ from "jquery";
import { downloadPdf } from "../../helpers/downloader";

const ContractInboxTableItem = ({ _item, _key }) => {
  const user = useSelector(state => state.user.data);
  const [status, setStatus] = useState(_item.contract_status);
  const [edited, setEdited] = useState(false);

  const updateContractApi = useApi(updateContract);
  const downloadFileApi = useApi(downloadFile);
  const sendContractEmailApi = useApi(sendContractEmail);

  // useEffect(() => {
  //   $("#inboxModal").on("hidden.bs.modal", function(e) {
  //     $("body").addClass("modal-open");
  //   });
  //   $("#keyInboxModal" + _key).on("hidden.bs.modal", function(e) {
  //     $("#inboxModal").modal("show");
  //   });
  //   $("#keyInboxModal").on("show.bs.modal", function(e) {
  //     $("#inboxModal").modal("hide");
  //   });
  //   $("#keyInboxModal" + _key).on("shown.bs.modal", function(e) {
  //     $("body").addClass("modal-open");
  //   });
  // }, []);

  const editContractHandling = status => {
    setStatus(status);
    setEdited(true);
  };

  const downloadFileHandling = async contractFile => {
    const response = await downloadFileApi.request(contractFile);
    if (response.ok) {
      downloadPdf(_item.contract_file.split("$")[2], response.data);
    } else {
      console.log("WHERE IS THE FILE???");
    }
  };

  const updateContractHandling = async (contractId, status) => {
    const response = await updateContractApi.request(contractId, status);
    if (response.ok) {
      alert("Update Contract Success");
      sendContractEmailHandling(_item.contractA_id);
    } else {
      alert("Update Contract Failed");
    }
  };

  const sendContractEmailHandling = async clientId => {
    const response = await sendContractEmailApi.request(1, clientId);
    if (response.ok) {
      alert("Mail sent");
      setEdited(false);
    } else {
      alert("Send mail failed");
    }
  };

  return (
    <tr key={_key}>
      <td className="align-middle">
        <p className="text-muted">{_item.contract_info}</p>
      </td>
      <td className="align-middle">
        <div className="btn-group">
          {_item.contract_hash !== "" ? (
            <p className="text-info">Registered</p>
          ) : (
            <AppDropdown
              _variant="outline-danger"
              _text={status}
              _displayToggle
            >
              {status !== "under construction" && (
                <a
                  class="dropdown-item"
                  onClick={() => {
                    console.log("AAA");
                    editContractHandling("under construction");
                  }}
                >
                  under construction
                </a>
              )}
              {status !== "waiting for approval" && (
                <a
                  class="dropdown-item"
                  onClick={() => editContractHandling("waiting for approval")}
                >
                  waiting for approval
                </a>
              )}
              {status !== "approved" && (
                <a
                  class="dropdown-item"
                  onClick={() => editContractHandling("approved")}
                >
                  approved
                </a>
              )}
              {status !== "rejected" && (
                <a
                  class="dropdown-item"
                  onClick={() => editContractHandling("rejected")}
                >
                  rejected
                </a>
              )}
            </AppDropdown>
          )}

          {/* <button
            type="button"
            className="btn btn-danger dropdown-toggle p-2"
            data-toggle="dropdown"
          >
            {status}
          </button>
          <div class="dropdown-menu">
            {status !== "under construction" && (
              <a
                class="dropdown-item"
                onClick={() => editContractHandling("under construction")}
              >
                under construction
              </a>
            )}
            {status !== "waiting for approval" && (
              <a
                class="dropdown-item"
                onClick={() => editContractHandling("waiting for approval")}
              >
                waiting for approval
              </a>
            )}
            {status !== "approved" && (
              <a
                class="dropdown-item"
                onClick={() => editContractHandling("approved")}
              >
                approved
              </a>
            )}
            {status !== "rejected" && (
              <a
                class="dropdown-item"
                onClick={() => editContractHandling("rejected")}
              >
                rejected
              </a>
            )}
          </div> */}
          {edited && (
            <>
              <div className="mx-2"></div>
              <AppButton
                _variant="outline-info"
                _text="Update"
                _iconName="save"
                _onClick={() => updateContractHandling(_item.id, status)}
                _loading={
                  updateContractApi.loading || sendContractEmailApi.loading
                }
              ></AppButton>
            </>
          )}
        </div>
      </td>
      <td className="align-middle">
        <p className="text-muted">{_item.updated}</p>
      </td>
      <td className="align-middle">
        <button type="button" className="btn" data-toggle="dropdown">
          <i className="fa fa-ellipsis-v text-muted"></i>
        </button>
        <div class="dropdown-menu">
          <a
            className="dropdown-item"
            onClick={() => downloadFileHandling(_item.contract_file)}
          >
            Download
          </a>
          <a
            class="dropdown-item"
            onClick={() => $("#keyInboxModal" + _item.id).modal("show")}
          >
            Get key
          </a>
        </div>
      </td>
    </tr>
  );
};

export default ContractInboxTableItem;
