import React from "react";
import AppCheckbox from "../common/AppCheckbox";
import useApi from "../../hooks/useApi";
import $ from "jquery";
import { useDispatch, useSelector } from "react-redux";
import {
  selectAction,
  deselectAction,
  removeContract
} from "../../actions/contractActions";
import { deleteContract, downloadFile } from "../../api/contractApi";
import { downloadPdf } from "../../helpers/downloader";
import AppButton from "../common/AppButton";
import AppDropdown from "../common/AppDropdown";
import AppLoader from "../common/AppLoader";

const ContractTableItem = ({ _item, _key }) => {
  const deleteContractApi = useApi(deleteContract);
  const downloadFileApi = useApi(downloadFile);
  const contractSelectedList = useSelector(
    state => state.contract.selectedList
  );
  const dispatch = useDispatch();

  const onCheckHandling = value => {
    if (value == true) {
      dispatch(selectAction(_item));
    } else {
      dispatch(deselectAction(_item.id));
    }
  };

  const deleteContractHandling = async contractId => {
    const response = await deleteContractApi.request(contractId);
    if (response.ok) {
      alert("Contract deleted");
      dispatch(removeContract(contractId));
    } else {
      alert("Delete contract failed");
    }
  };

  const downloadFileHandling = async contractFile => {
    const response = await downloadFileApi.request(contractFile);
    if (response.ok) {
      downloadPdf(_item.contract_file.split("$")[2], response.data);
    } else {
      console.log("WHERE IS THE FILE???");
    }
  };

  return (
    <>
      <tr key={_key}>
        {_item.contract_hash === "" &&
          _item.contract_status === "approved" &&
          contractSelectedList.some(contract => contract.id === _item.id) && (
            <td className="align-middle">
              <AppCheckbox
                _onChange={event => {
                  onCheckHandling(event.target.checked);
                }}
                _checked={true}
              ></AppCheckbox>
            </td>
          )}
        {_item.contract_hash === "" &&
          _item.contract_status === "approved" &&
          !contractSelectedList.some(contract => contract.id === _item.id) && (
            <td className="align-middle">
              <AppCheckbox
                _onChange={event => {
                  onCheckHandling(event.target.checked);
                }}
                _checked={false}
              ></AppCheckbox>
            </td>
          )}
        {/* {_item.contract_hash === "" &&
          _item.contract_status !== "approved" &&
          contractSelectedList.some(contract => contract.id === _item.id) && (
            <td className="align-middle">
              <AppCheckbox
                _onChange={event => {
                  onCheckHandling(event.target.checked);
                }}
                _checked={true}
              ></AppCheckbox>
              <p>checked</p>
            </td>
          )}
        {_item.contract_hash === "" &&
          _item.contract_status !== "approved" &&
          !contractSelectedList.some(contract => contract.id === _item.id) && (
            <td className="align-middle">
              <AppCheckbox
                _onChange={event => {
                  onCheckHandling(event.target.checked);
                }}
                _checked={false}
              ></AppCheckbox>
              <p>unchecked</p>
            </td>
          )} */}
        {_item.contract_status !== "approved" && (
          <td className="align-middle">
            <p className="text-danger">Pending</p>
          </td>
        )}
        {_item.contract_hash !== "" && (
          <td className="align-middle">
            <p className="text-info">Registered</p>
          </td>
        )}
        <td className="align-middle">
          <p className="text-muted">{_item.contract_info}</p>
        </td>
        <td className="align-middle">
          <p className="text-muted">{_item.contract_status}</p>
        </td>
        <td className="align-middle">
          <p className="text-muted">{_item.updated}</p>
        </td>
        <td className="align-middle">
          <div className="d-inline-block">
            {/* <AppLoader _height={50} _type="Oval" _color="#00BFFF"></AppLoader> */}
            <AppDropdown _iconName="ellipsis-v" _contentVariant="muted">
              <a
                class="dropdown-item"
                onClick={() => {
                  deleteContractHandling(_item.id);
                }}
              >
                Delete
              </a>
              <a
                class="dropdown-item"
                onClick={() => {
                  downloadFileHandling(_item.contract_file);
                }}
              >
                Download
              </a>
              {_item.contract_hash !== "" && (
                <a
                  class="dropdown-item"
                  onClick={() => $("#keyModal" + _item.id).modal("show")}
                >
                  Get key
                </a>
              )}
            </AppDropdown>
          </div>
        </td>
        {/* <td className="align-middle">
          <AppButton
            _text="TEST"
            _variant="outline-warning"
            _onClick={() => console.log(contractSelectedList)}
          ></AppButton>
        </td> */}
      </tr>
    </>
  );
};

export default ContractTableItem;
