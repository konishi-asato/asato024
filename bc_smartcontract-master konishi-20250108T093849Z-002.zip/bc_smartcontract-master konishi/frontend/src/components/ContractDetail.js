import React from "react";

const ContractDetail = _item => {
  return <div></div>;
};

export default ContractDetail;
