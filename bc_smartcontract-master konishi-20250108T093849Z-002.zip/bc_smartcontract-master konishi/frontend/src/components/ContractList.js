import React, { useState, useEffect } from "react";
import DataTable from "../components/table/DataTable";
import ContractTableItem from "./table/ContractTableItem";
import AppButton from "../components/common/AppButton";
import AppLoader from "../components/common/AppLoader";
import $ from "jquery";
import ContractModal from "../components/modal/ContractModal";
import { getContractsByUserId } from "../api/contractApi";
import useApi from "../hooks/useApi";
import { useSelector, useDispatch } from "react-redux";
import KeyModalList from "./modal/KeyModalList";
import dummyData from "./dummyData";
import { loadContract } from "../actions/contractActions";

const ContractList = () => {
  const types = [
    "All",
    "Under Construction",
    "Waiting For Approval",
    "Approved",
    "Rejected"
  ];

  const [selectedType, setSelectedType] = useState("All");
  const dispatch = useDispatch();
  const contractList = useSelector(state => state.contract.list);
  const user = useSelector(state => state.user.data);
  const getContractsByUserIdApi = useApi(getContractsByUserId);

  useEffect(async () => {
    if (user != null) {
      const response = await getContractsByUserIdApi.request(user.user_id);
      if (response.ok) {
        dispatch(loadContract(response.data));
      }
    }
  }, []);

  const filterContracts = (contracts, status) => {
    if (status === "All") return contracts;
    if (status !== "All")
      return contracts.filter(
        contract =>
          contract.contract_status.toUpperCase() === status.toUpperCase()
      );
  };

  const countContract = (contracts, status) => {
    if (status === "All") return contracts.length;
    if (status !== "All") {
      var count = 0;
      for (var i = 0; i < contracts.length; ++i) {
        if (contracts[i].contract_status.toUpperCase() == status.toUpperCase())
          count++;
      }
      return count;
    }
  };

  return (
    <div className="row">
      <div className="col-lg-4">
        <strong>Contract List</strong>
        <br></br>
        <br></br>
        {types.map((item, i) => {
          return (
            <div key={i} className="row">
              <div className="col-9">
                <a
                  className="text-muted font-weight-bold"
                  onClick={() => setSelectedType(item)}
                >
                  <i className={"fa fa-star"}></i> {item}
                </a>
              </div>
              <div className="col-3">
                <p className="bg-danger text-white text-center rounded-pill">
                  {countContract(contractList, item)}
                </p>
              </div>
            </div>
          );
        })}
        <br></br>
        <br></br>
      </div>

      <div className="col-lg-8">
        <strong>Uploaded Contracts</strong>
        <br></br>
        <br></br>
        <ContractModal _id="contractModal"></ContractModal>
        {getContractsByUserIdApi.loading && <AppLoader></AppLoader>}
        {user !== null &&
          user !== undefined &&
          getContractsByUserIdApi.success && (
            <>
              <DataTable
                _id="contractTable"
                _component={ContractTableItem}
                _data={filterContracts(contractList, selectedType)}
                _headers={["", "Info", "Status", "Updated Date", ""]}
              ></DataTable>
              <KeyModalList _id="keyModal" _data={contractList}></KeyModalList>
              <div className="d-flex justify-content-center">
                <AppButton
                  _variant="outline-info"
                  _text={"Create Contract"}
                  _iconName="file-text"
                  _onClick={() => $("#contractModal").modal("show")}
                ></AppButton>
              </div>
              <ContractModal _id="contractModal"></ContractModal>
            </>
          )}
        {/* {user !== null &&
          user !== undefined &&
          getContractsByClientIdApi.success &&
          contractList === [] && (
            <>
              <DataTable
                _id="contractTable"
                _component={ContractTableItem}
                _data={[]}
                _headers={["", "Info", "Status", "Updated Date", ""]}
              ></DataTable>

              <div className="d-flex justify-content-center">
                <AppButton
                  _variant="outline-info"
                  _text={"Create Contract"}
                  _iconName="file-text"
                  _onClick={() => $("#contractModal").modal("show")}
                ></AppButton>
              </div>
              <ContractModal _id="contractModal"></ContractModal>
            </>
          )} */}
        {user === null && user !== undefined && (
          <>
            <DataTable
              _component={ContractTableItem}
              _data={[]}
              _headers={["", "Info", "Status", "Updated Date"]}
            ></DataTable>
            <p className="text-muted text-center">
              Please login to your account
            </p>
            <div className="d-flex justify-content-center">
              <AppButton
                _variant="outline-info"
                _text={"Login"}
                _iconName="user"
                _onClick={() => $("#loginModal").modal("show")}
              ></AppButton>
            </div>
          </>
        )}
        {user !== null && user !== undefined && getContractsByUserIdApi.error && (
          <>
            <DataTable
              _component={ContractTableItem}
              _data={[]}
              _headers={["", "Info", "Status", "Updated Date"]}
            ></DataTable>
            <p className="text-muted text-center">
              There is a connection error!
            </p>
            <div className="d-flex justify-content-center">
              <AppButton
                _variant="outline-info"
                _text={"Retry"}
                _iconName="refresh"
                _onClick={() => getContractsByUserIdApi.request(user.user_id)}
              ></AppButton>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ContractList;
