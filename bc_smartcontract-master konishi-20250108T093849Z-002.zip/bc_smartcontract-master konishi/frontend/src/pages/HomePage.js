import React, { useState, useEffect } from "react";

import ContractSearch from "../components/ContractSearch";
import ContractList from "../components/ContractList";

import useApi from "../hooks/useApi";
import Container from "../components/common/Container";
import Page from "../components/common/Page";

const HomePage = () => {
  return (
    <Page>
      <div className="container">
        <div className="row">
          <div className="col-xl-4"></div>
          <div className="col-xl-8">
            <br></br>
            <br></br>
            <Container _shadow>
              <ContractSearch></ContractSearch>
            </Container>
            <br></br>
            <br></br>
          </div>
        </div>

        <Container _shadow>
          <ContractList></ContractList>
        </Container>
        <br></br>
        <br></br>
      </div>
    </Page>
  );
};

export default HomePage;
